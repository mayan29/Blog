//
//  ViewController.m
//  排版引擎框架
//
//  Created by mayan on 2017/4/28.
//  Copyright © 2017年 mayan. All rights reserved.
//

#import "ViewController.h"

#import "MYView.h"
#import "MYFrameParserConfig.h"
#import "CoreTextData.h"
#import "MYFrameParser.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet MYView *myView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    NSString *content = @"一家最传统的服装企业通过“互联网+”和“双创”转型升级，年出口额达到15亿美元，同时吸纳了大量就业；来自小微企业的小商品源源不断地通过威海港运往周边和欧美国家。李克强在会上谈起上周在山东的考察时感叹道：“中国老百姓中真是蕴藏着无穷的创造力！”";
    
    
    MYFrameParserConfig *config = [[MYFrameParserConfig alloc] init];
    config.textColor = [UIColor blackColor];
    config.width = self.myView.bounds.size.width;
    
    CoreTextData *data = [MYFrameParser parseContent:content config:config];
    self.myView.data = data;
    self.myView.height = data.height;
}


@end
