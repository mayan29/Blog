//
//  MYFrameParser.h
//  排版引擎框架
//
//  Created by mayan on 2017/4/27.
//  Copyright © 2017年 mayan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MYFrameParserConfig;
@class CoreTextData;
@interface MYFrameParser : NSObject


+ (CoreTextData *)parseContent:(NSString *)content config:(MYFrameParserConfig *)config;

@end
