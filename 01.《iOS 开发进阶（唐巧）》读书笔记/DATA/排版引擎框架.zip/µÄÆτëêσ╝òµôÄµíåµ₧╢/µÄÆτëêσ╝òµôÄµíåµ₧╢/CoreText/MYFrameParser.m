//
//  MYFrameParser.m
//  排版引擎框架
//
//  Created by mayan on 2017/4/27.
//  Copyright © 2017年 mayan. All rights reserved.
//

#import "MYFrameParser.h"
#import "CoreTextData.h"
#import "MYFrameParserConfig.h"
#import <CoreText/CoreText.h>

@implementation MYFrameParser


+ (NSDictionary *)attributesWithConfig:(MYFrameParserConfig *)config
{
    
    // 0.textColor
    UIColor *textColor = config.textColor;
    CGColorRef textColorRef = textColor.CGColor;
    
    
    // 1.fontSize
    CGFloat fontSize = config.fontSize;
    CTFontRef fontRef = CTFontCreateWithName((CFStringRef)@"ArialMT", fontSize, NULL);
    
    
    // 2.lineSpacing
    CGFloat lineSpacing = config.lineSpace;
    
    const CFIndex kNumberOfSettings = 3;
    CTParagraphStyleSetting theSettings[kNumberOfSettings] = {  // 段落样式
    
        { kCTParagraphStyleSpecifierLineSpacingAdjustment, sizeof(CGFloat), &lineSpacing },  // 段落样式行间距调整
        { kCTParagraphStyleSpecifierMaximumLineSpacing, sizeof(CGFloat), &lineSpacing },  // 段落样式的最大间距
        { kCTParagraphStyleSpecifierMinimumLineSpacing, sizeof(CGFloat), &lineSpacing }  // 段落样式的最小间距
    };
    
    CTParagraphStyleRef theParagraphRef = CTParagraphStyleCreate(theSettings, kNumberOfSettings);
    
    
    // 生成字典
    NSDictionary *dic = @{
                          (id)kCTForegroundColorAttributeName : (__bridge id)textColorRef,
                          (id)kCTFontAttributeName : (__bridge id)fontRef,
                          (id)kCTParagraphStyleAttributeName : (id)theParagraphRef
                          };
    
    
    CFRelease(theParagraphRef);
    CFRelease(fontRef);
    return dic;
}



+ (CoreTextData *)parseContent:(NSString *)content config:(MYFrameParserConfig *)config
{
    NSDictionary *attributes = [self attributesWithConfig:config];
    NSAttributedString *contentString = [[NSAttributedString alloc] initWithString:content attributes:attributes];
    
    // 创建 CTFramesetterRef 实例
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)contentString);
    
    // 获得要绘制的区域的高度
    CGSize restrictSize = CGSizeMake(config.width, CGFLOAT_MAX);
    CGSize coreTextSize = CTFramesetterSuggestFrameSizeWithConstraints(framesetter, CFRangeMake(0, 0), nil, restrictSize, nil);
    CGFloat textHeight = coreTextSize.height;
    
    // 生成 CTFrameRef 实例
    CTFrameRef frame = [self createFrameWithFramesetter:framesetter config:config height:textHeight];
    
    // 将生成好的 CTFrameRef 实例和计算好的绘制高度保存到 CoreTextData 实例中，最后返回 CoreTextData 实例
    CoreTextData *data = [[CoreTextData alloc] init];
    data.ctFrame = frame;
    data.height = textHeight;
                        
    // 释放内存
    CFRelease(frame);
    CFRelease(framesetter);
    return data;
}

+ (CTFrameRef)createFrameWithFramesetter:(CTFramesetterRef)framesetter config:(MYFrameParserConfig *)config height:(CGFloat)height
{
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, CGRectMake(0, 0, config.width, height));
    
    CTFrameRef frame = CTFramesetterCreateFrame(framesetter, CFRangeMake(0, 0), path, NULL);
    CFRelease(path);
    return frame;
}

@end
