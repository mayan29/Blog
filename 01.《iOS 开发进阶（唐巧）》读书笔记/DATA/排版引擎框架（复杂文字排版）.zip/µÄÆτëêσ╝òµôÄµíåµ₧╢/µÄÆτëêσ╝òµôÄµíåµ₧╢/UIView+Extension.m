//
//  UIView+Extension.m
//  排版引擎框架
//
//  Created by mayan on 2017/4/28.
//  Copyright © 2017年 mayan. All rights reserved.
//

#import "UIView+Extension.h"

@implementation UIView (Extension)



- (CGFloat)height
{
    return self.bounds.size.height;
}


- (void)setHeight:(CGFloat)height
{
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}


@end
