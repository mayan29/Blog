//
//  CoreTextData.h
//  排版引擎框架
//
//  Created by mayan on 2017/4/27.
//  Copyright © 2017年 mayan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreText/CoreText.h>


@interface CoreTextData : NSObject


@property (nonatomic, assign) CTFrameRef ctFrame;
@property (nonatomic, assign) CGFloat height;

@end
