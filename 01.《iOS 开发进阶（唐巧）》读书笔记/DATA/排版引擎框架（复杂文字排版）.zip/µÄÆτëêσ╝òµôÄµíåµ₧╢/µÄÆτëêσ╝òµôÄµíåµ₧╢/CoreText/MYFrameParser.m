//
//  MYFrameParser.m
//  排版引擎框架
//
//  Created by mayan on 2017/4/27.
//  Copyright © 2017年 mayan. All rights reserved.
//

#import "MYFrameParser.h"
#import "CoreTextData.h"
#import "MYFrameParserConfig.h"
#import <CoreText/CoreText.h>

@implementation MYFrameParser




#pragma mark - 1.简单文字排版
+ (CoreTextData *)parseContent:(NSString *)content config:(MYFrameParserConfig *)config
{
    NSDictionary *attributes = [self attributesWithConfig:config];
    NSAttributedString *contentString = [[NSAttributedString alloc] initWithString:content attributes:attributes];
    
    // 创建 CTFramesetterRef 实例
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)contentString);
    
    // 获得要绘制的区域的高度
    CGSize restrictSize = CGSizeMake(config.width, CGFLOAT_MAX);
    CGSize coreTextSize = CTFramesetterSuggestFrameSizeWithConstraints(framesetter, CFRangeMake(0, 0), nil, restrictSize, nil);
    CGFloat textHeight = coreTextSize.height;
    
    // 生成 CTFrameRef 实例
    CTFrameRef frame = [self createFrameWithFramesetter:framesetter config:config height:textHeight];
    
    // 将生成好的 CTFrameRef 实例和计算好的绘制高度保存到 CoreTextData 实例中，最后返回 CoreTextData 实例
    CoreTextData *data = [[CoreTextData alloc] init];
    data.ctFrame = frame;
    data.height = textHeight;
                        
    // 释放内存
    CFRelease(frame);
    CFRelease(framesetter);
    return data;
}

+ (NSDictionary *)attributesWithConfig:(MYFrameParserConfig *)config
{
    
    // 0.textColor
    UIColor *textColor = config.textColor;
    CGColorRef textColorRef = textColor.CGColor;
    
    
    // 1.fontSize
    CGFloat fontSize = config.fontSize;
    CTFontRef fontRef = CTFontCreateWithName((CFStringRef)@"ArialMT", fontSize, NULL);
    
    
    // 2.lineSpacing
    CGFloat lineSpacing = config.lineSpace;
    
    const CFIndex kNumberOfSettings = 3;
    CTParagraphStyleSetting theSettings[kNumberOfSettings] = {  // 段落样式
        
        { kCTParagraphStyleSpecifierLineSpacingAdjustment, sizeof(CGFloat), &lineSpacing },  // 段落样式行间距调整
        { kCTParagraphStyleSpecifierMaximumLineSpacing, sizeof(CGFloat), &lineSpacing },  // 段落样式的最大间距
        { kCTParagraphStyleSpecifierMinimumLineSpacing, sizeof(CGFloat), &lineSpacing }  // 段落样式的最小间距
    };
    
    CTParagraphStyleRef theParagraphRef = CTParagraphStyleCreate(theSettings, kNumberOfSettings);
    
    
    // 生成字典
    NSDictionary *dic = @{
                          (id)kCTForegroundColorAttributeName : (__bridge id)textColorRef,
                          (id)kCTFontAttributeName : (__bridge id)fontRef,
                          (id)kCTParagraphStyleAttributeName : (id)theParagraphRef
                          };
    
    
    CFRelease(theParagraphRef);
    CFRelease(fontRef);
    return dic;
}


#pragma mark - 2.复杂文字排版
+ (CoreTextData *)parseStrArray:(NSArray *)strArray config:(MYFrameParserConfig *)config
{
    NSAttributedString *contentString = [self attributesWithConfig:config array:strArray];
    
    // 创建 CTFramesetterRef 实例
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)contentString);
    
    // 获得要绘制的区域的高度
    CGSize restrictSize = CGSizeMake(config.width, CGFLOAT_MAX);
    CGSize coreTextSize = CTFramesetterSuggestFrameSizeWithConstraints(framesetter, CFRangeMake(0, 0), nil, restrictSize, nil);
    CGFloat textHeight = coreTextSize.height;
    
    // 生成 CTFrameRef 实例
    CTFrameRef frame = [self createFrameWithFramesetter:framesetter config:config height:textHeight];
    
    // 将生成好的 CTFrameRef 实例和计算好的绘制高度保存到 CoreTextData 实例中，最后返回 CoreTextData 实例
    CoreTextData *data = [[CoreTextData alloc] init];
    data.ctFrame = frame;
    data.height = textHeight;
    
    // 释放内存
    CFRelease(frame);
    CFRelease(framesetter);
    return data;
}

+ (NSAttributedString *)attributesWithConfig:(MYFrameParserConfig *)config array:(NSArray *)array
{
    NSMutableAttributedString *contentString = [[NSMutableAttributedString alloc] init];
    for (NSDictionary *dic in array) {
        
        NSAttributedString *str = [self stringWithDic:dic config:config];
        
        if (str) {
            [contentString appendAttributedString:str];
        }
    }
    
    return contentString;
}

+ (NSAttributedString *)stringWithDic:(NSDictionary *)dic config:(MYFrameParserConfig *)config
{
    
    if ([dic[@"type"] isEqualToString:@"txt"]) {
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        // color
        UIColor *color = [self colorFromeTemplate:dic[@"color"]];
        if (color == nil) {
            color = config.textColor;
        }
        attributes[(id)kCTForegroundColorAttributeName] = (__bridge id _Nullable)(color.CGColor);
        
        // size
        CGFloat fontSize = [dic[@"size"] floatValue];
        if (fontSize > 0) {
            CTFontRef fontRef = CTFontCreateWithName((CFStringRef)@"ArialMT", fontSize, NULL);
            attributes[(id)kCTFontAttributeName] = (__bridge id _Nullable)(fontRef);
            CFRelease(fontRef);
        }
        
        // content
        NSString *content = dic[@"content"];
        
        
        return [[NSAttributedString alloc] initWithString:content attributes:attributes];
    } else return nil;
}

+ (UIColor *)colorFromeTemplate:(NSString *)name
{
    if ([name isEqualToString:@"blue"]) {
        return [UIColor blueColor];
    }
    else if ([name isEqualToString:@"red"])
    {
        return [UIColor redColor];
    }
    else if ([name isEqualToString:@"black"])
    {
        return [UIColor blackColor];
    }
    else return nil;
}




#pragma mark - 公共方法
+ (CTFrameRef)createFrameWithFramesetter:(CTFramesetterRef)framesetter config:(MYFrameParserConfig *)config height:(CGFloat)height
{
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, CGRectMake(0, 0, config.width, height));
    
    CTFrameRef frame = CTFramesetterCreateFrame(framesetter, CFRangeMake(0, 0), path, NULL);
    CFRelease(path);
    return frame;
}

@end
