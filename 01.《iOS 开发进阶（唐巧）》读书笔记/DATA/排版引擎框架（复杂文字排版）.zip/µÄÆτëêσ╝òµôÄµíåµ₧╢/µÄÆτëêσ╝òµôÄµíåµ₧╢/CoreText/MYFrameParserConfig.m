//
//  MYFrameParserConfig.m
//  排版引擎框架
//
//  Created by mayan on 2017/4/27.
//  Copyright © 2017年 mayan. All rights reserved.
//

#import "MYFrameParserConfig.h"

@implementation MYFrameParserConfig



- (instancetype)init
{
    self = [super init];
    if (self) {
        
        _width = 200.0f;
        _fontSize = 16.0f;
        _lineSpace = 8.0f;
        _textColor = [UIColor blackColor];
    }
    return self;
}

@end
