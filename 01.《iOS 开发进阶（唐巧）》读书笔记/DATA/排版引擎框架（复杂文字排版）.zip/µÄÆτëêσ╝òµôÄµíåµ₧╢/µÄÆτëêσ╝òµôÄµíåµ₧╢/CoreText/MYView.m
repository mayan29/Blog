//
//  MYView.m
//  排版引擎框架
//
//  Created by mayan on 2017/4/27.
//  Copyright © 2017年 mayan. All rights reserved.
//

#import "MYView.h"
#import "CoreTextData.h"

@implementation MYView


- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    CGContextTranslateCTM(context, 0, self.bounds.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    if (self.data) {
        CTFrameDraw(self.data.ctFrame, context);
    }
}

@end
